package com.example.paisacheck360

data class LogItem(
    val domain: String = "",
    val status: String = "",
    val timestamp: Long = 0L
)
