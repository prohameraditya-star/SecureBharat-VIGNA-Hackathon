package com.example.paisacheck360

data class ScamVideo(
    val title: String,
    val videoId: String
)
